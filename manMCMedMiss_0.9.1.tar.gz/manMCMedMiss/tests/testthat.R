library(testthat)
library(manMCMedMiss)

test_check("manMCMedMiss")
